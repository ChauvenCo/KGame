package com.kgame.game;

public class ScreenSize {
    public static float width = 1422.0f;
    public static float height = 720.0f;
    public static int iwidth = 1422;
    public static int iheight = 720;
}
